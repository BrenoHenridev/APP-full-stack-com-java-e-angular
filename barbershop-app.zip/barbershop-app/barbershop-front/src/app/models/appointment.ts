
export interface Appointment {
  id?: number;
  customerName: string;
  barberName: string;
  dateTime: string;
}
