
import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import { Appointment } from '../../models/appointment';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html'
})
export class AppointmentListComponent implements OnInit {
  appointments: Appointment[] = [];

  constructor(private service: AppointmentService) {}

  ngOnInit() {
    this.service.getAll().subscribe(data => this.appointments = data);
  }
}
