
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppointmentService } from '../../services/appointment.service';

@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html'
})
export class AppointmentFormComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder, private service: AppointmentService) {
    this.form = this.fb.group({
      customerName: [''],
      barberName: [''],
      dateTime: ['']
    });
  }

  submit() {
    this.service.create(this.form.value).subscribe(() => {
      alert('Agendamento criado com sucesso!');
      this.form.reset();
    });
  }
}
